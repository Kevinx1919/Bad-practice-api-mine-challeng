﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace apix1.Migrations
{
    public partial class AddUniqueConstraints : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // 1. ELIMINAR ÍNDICES EXISTENTES (si existen)
            migrationBuilder.Sql(@"
                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerEmail' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    DROP INDEX IndexCustomerEmail ON Customer;
                END;

                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerPhone' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    DROP INDEX IndexCustomerPhone ON Customer;
                END;

                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexSupplierEmail' AND object_id = OBJECT_ID('Supplier'))
                BEGIN
                    DROP INDEX IndexSupplierEmail ON Supplier;
                END;

                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexSupplierName' AND object_id = OBJECT_ID('Supplier'))
                BEGIN
                    DROP INDEX IndexSupplierName ON Supplier;
                END;
            ");

            // 2. VERIFICAR Y CORREGIR DUPLICADOS (con puntos y coma corregidos)
            migrationBuilder.Sql(@"
                -- Verificar y corregir duplicados en Email de Customer
                WITH DuplicateEmails AS (
                    SELECT Email, COUNT(*) as Count
                    FROM Customer
                    WHERE Email IS NOT NULL AND Email != ''
                    GROUP BY Email
                    HAVING COUNT(*) > 1
                )
                UPDATE c
                SET c.Email = CONCAT('unique_', c.Id, '_', c.Email)
                FROM Customer c
                INNER JOIN DuplicateEmails d ON c.Email = d.Email
                WHERE c.Id NOT IN (
                    SELECT MIN(Id) 
                    FROM Customer 
                    WHERE Email IS NOT NULL AND Email != ''
                    GROUP BY Email
                );

                -- Verificar y corregir duplicados en Phone de Customer
                WITH DuplicatePhones AS (
                    SELECT Phone, COUNT(*) as Count
                    FROM Customer
                    WHERE Phone IS NOT NULL AND Phone != ''
                    GROUP BY Phone
                    HAVING COUNT(*) > 1
                )
                UPDATE c
                SET c.Phone = CONCAT('unique_', c.Id, '_', c.Phone)
                FROM Customer c
                INNER JOIN DuplicatePhones d ON c.Phone = d.Phone
                WHERE c.Id NOT IN (
                    SELECT MIN(Id) 
                    FROM Customer 
                    WHERE Phone IS NOT NULL AND Phone != ''
                    GROUP BY Phone
                );

                -- Verificar y corregir duplicados en Email de Supplier
                WITH DuplicateSupplierEmails AS (
                    SELECT Email, COUNT(*) as Count
                    FROM Supplier
                    WHERE Email IS NOT NULL AND Email != ''
                    GROUP BY Email
                    HAVING COUNT(*) > 1
                )
                UPDATE s
                SET s.Email = CONCAT('unique_', s.Id, '_', s.Email)
                FROM Supplier s
                INNER JOIN DuplicateSupplierEmails d ON s.Email = d.Email
                WHERE s.Id NOT IN (
                    SELECT MIN(Id) 
                    FROM Supplier 
                    WHERE Email IS NOT NULL AND Email != ''
                    GROUP BY Email
                );

                -- Verificar y corregir duplicados en CompanyName de Supplier
                WITH DuplicateCompanyNames AS (
                    SELECT CompanyName, COUNT(*) as Count
                    FROM Supplier
                    WHERE CompanyName IS NOT NULL AND CompanyName != ''
                    GROUP BY CompanyName
                    HAVING COUNT(*) > 1
                )
                UPDATE s
                SET s.CompanyName = CONCAT('unique_', s.Id, '_', s.CompanyName)
                FROM Supplier s
                INNER JOIN DuplicateCompanyNames d ON s.CompanyName = d.CompanyName
                WHERE s.Id NOT IN (
                    SELECT MIN(Id) 
                    FROM Supplier 
                    WHERE CompanyName IS NOT NULL AND CompanyName != ''
                    GROUP BY CompanyName
                );
            ");

            // 3. CREAR ÍNDICES CON RESTRICCIONES ÚNICAS
            migrationBuilder.Sql(@"
                -- Índices únicos para Customer
                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerEmail' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    CREATE UNIQUE INDEX IndexCustomerEmail ON Customer (Email) WHERE Email IS NOT NULL;
                END
                ELSE
                BEGIN
                    DROP INDEX IndexCustomerEmail ON Customer;
                    CREATE UNIQUE INDEX IndexCustomerEmail ON Customer (Email) WHERE Email IS NOT NULL;
                END;

                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerPhone' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    CREATE UNIQUE INDEX IndexCustomerPhone ON Customer (Phone) WHERE Phone IS NOT NULL;
                END
                ELSE
                BEGIN
                    DROP INDEX IndexCustomerPhone ON Customer;
                    CREATE UNIQUE INDEX IndexCustomerPhone ON Customer (Phone) WHERE Phone IS NOT NULL;
                END;

                -- Índices únicos para Supplier
                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexSupplierEmail' AND object_id = OBJECT_ID('Supplier'))
                BEGIN
                    CREATE UNIQUE INDEX IndexSupplierEmail ON Supplier (Email) WHERE Email IS NOT NULL;
                END
                ELSE
                BEGIN
                    DROP INDEX IndexSupplierEmail ON Supplier;
                    CREATE UNIQUE INDEX IndexSupplierEmail ON Supplier (Email) WHERE Email IS NOT NULL;
                END;

                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexSupplierName' AND object_id = OBJECT_ID('Supplier'))
                BEGIN
                    CREATE UNIQUE INDEX IndexSupplierName ON Supplier (CompanyName) WHERE CompanyName IS NOT NULL;
                END
                ELSE
                BEGIN
                    DROP INDEX IndexSupplierName ON Supplier;
                    CREATE UNIQUE INDEX IndexSupplierName ON Supplier (CompanyName) WHERE CompanyName IS NOT NULL;
                END;
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // REVERTIR: Eliminar restricciones únicas
            migrationBuilder.Sql(@"
                -- Eliminar índices únicos
                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerEmail' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    DROP INDEX IndexCustomerEmail ON Customer;
                END;

                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerPhone' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    DROP INDEX IndexCustomerPhone ON Customer;
                END;

                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexSupplierEmail' AND object_id = OBJECT_ID('Supplier'))
                BEGIN
                    DROP INDEX IndexSupplierEmail ON Supplier;
                END;

                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexSupplierName' AND object_id = OBJECT_ID('Supplier'))
                BEGIN
                    DROP INDEX IndexSupplierName ON Supplier;
                END;

                -- Recrear índices normales (no únicos)
                CREATE INDEX IndexCustomerEmail ON Customer (Email);
                CREATE INDEX IndexCustomerPhone ON Customer (Phone);
                CREATE INDEX IndexSupplierEmail ON Supplier (Email);
                CREATE INDEX IndexSupplierName ON Supplier (CompanyName);
            ");
        }
    }
}