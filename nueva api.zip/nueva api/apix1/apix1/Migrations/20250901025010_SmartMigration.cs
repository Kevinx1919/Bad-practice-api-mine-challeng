﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace apix1.Migrations
{
    public partial class SmartMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // AGREGAR COLUMNAS SOLO SI NO EXISTEN
            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                              WHERE TABLE_NAME = 'Customer' AND COLUMN_NAME = 'Email')
                BEGIN
                    ALTER TABLE [Customer] ADD [Email] NVARCHAR(100) NOT NULL DEFAULT ''
                END
            ");

            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                              WHERE TABLE_NAME = 'Customer' AND COLUMN_NAME = 'DateOfBirth')
                BEGIN
                    ALTER TABLE [Customer] ADD [DateOfBirth] DATE NOT NULL DEFAULT '2000-01-01'
                END
            ");

            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                              WHERE TABLE_NAME = 'Supplier' AND COLUMN_NAME = 'Email')
                BEGIN
                    ALTER TABLE [Supplier] ADD [Email] NVARCHAR(100) NOT NULL DEFAULT ''
                END
            ");

            // ACTUALIZAR DATOS PARA UNICIDAD
            migrationBuilder.Sql(@"
                UPDATE Customer SET Email = CONCAT('customer', Id, '@company.com') WHERE Email = '' OR Email IS NULL;
                UPDATE Supplier SET Email = CONCAT('supplier', Id, '@company.com') WHERE Email = '' OR Email IS NULL;
            ");

            // CREAR ÍNDICES SOLO SI NO EXISTEN
            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerEmail' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    CREATE INDEX [IndexCustomerEmail] ON [Customer] ([Email])
                END
            ");

            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerPhone' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    CREATE INDEX [IndexCustomerPhone] ON [Customer] ([Phone])
                END
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Eliminar índices (opcional, para reversión)
            migrationBuilder.Sql(@"
                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerEmail' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    DROP INDEX [IndexCustomerEmail] ON [Customer]
                END
            ");

            migrationBuilder.Sql(@"
                IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IndexCustomerPhone' AND object_id = OBJECT_ID('Customer'))
                BEGIN
                    DROP INDEX [IndexCustomerPhone] ON [Customer]
                END
            ");

            // Eliminar columnas (opcional)
            migrationBuilder.Sql(@"
                IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
                          WHERE TABLE_NAME = 'Customer' AND COLUMN_NAME = 'Email')
                BEGIN
                    ALTER TABLE [Customer] DROP COLUMN [Email]
                END
            ");
        }
    }
}