﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace apix1.Models;

[Table("Supplier")]
[Index("Country", Name = "IndexSupplierCountry")]

[Index("CompanyName", Name = "IndexSupplierName", IsUnique = true)]
[Index("Email", Name = "IndexSupplierEmail", IsUnique = true)]
public partial class Supplier
{
    [Key]
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre de la compañia es obligatorio")]
    [StringLength(40)]
    public string CompanyName { get; set; } = null!;


    [StringLength(50)]
    public string? ContactName { get; set; }

    [StringLength(40)]
    public string? ContactTitle { get; set; }

    [StringLength(40)]
    public string? City { get; set; }

    [StringLength(40)]
    public string? Country { get; set; }

    [Required(ErrorMessage = "El numero es obligatorio")]
    [RegularExpression(@"^\(\+57\)\s\d{10}$", ErrorMessage = "El formato debe ser (+57) 3144427602")]
    [StringLength(30)]
    public string? Phone { get; set; } = null!;

    [StringLength(30)]
    public string? Fax { get; set; }

    [Required(ErrorMessage = "el correo es obligatorio")]
    [EmailAddress(ErrorMessage = "El formato del correo no es valido")]
    [StringLength(100)]
    public string? Email { get; set; } = null!;

    [InverseProperty("Supplier")]
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}