﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace apix1.Models;

[Table("Product")]
[Index("ProductName", Name = "IndexProductName", IsUnique = true)]
public partial class Product
{
    [Key]
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre del producto es obligatorio")]
    [StringLength(50, ErrorMessage = "El nombre no puede exceder 50 caracteres")]
    public string ProductName { get; set; } = null!;

    [Required(ErrorMessage = "el proovedor es obligatorio")]
    public int SupplierId { get; set; }

    [Column(TypeName = "decimal(12, 2)")]
    public decimal? UnitPrice { get; set; }

    [StringLength(30)]
    public string? Package { get; set; }

    public bool IsDiscontinued { get; set; }

    [InverseProperty("Product")]
    public virtual ICollection<OrderItem>? OrderItems { get; set; } = new List<OrderItem>();

    [ForeignKey("SupplierId")]
    [InverseProperty("Products")]
    public virtual Supplier? Supplier { get; set; } = null!;
}