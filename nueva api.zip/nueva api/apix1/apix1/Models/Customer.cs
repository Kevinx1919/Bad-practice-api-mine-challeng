﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace apix1.Models;

[Table("Customer")]
[Index("Phone", Name = "IndexCustomerPhone", IsUnique = true)] // Restricción única para teléfono
[Index("Email", Name = "IndexCustomerEmail", IsUnique = true)] // Restricción única para email
[Index("LastName", "FirstName", Name = "IndexCustomerName")]
public partial class Customer
{
    [Key]
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio")]
    [StringLength(40, ErrorMessage = "El nombre no puede exceder 40 caracteres")]
    public string FirstName { get; set; } = null!;

    [Required(ErrorMessage = "El apellido es obligatorio")]
    [StringLength(40, ErrorMessage = "El apellido no puede exceder 40 caracteres")]
    public string LastName { get; set; } = null!;

    [StringLength(40)]
    public string? City { get; set; }

    [StringLength(40)]
    public string? Country { get; set; }

    [Required(ErrorMessage = "El teléfono es obligatorio")]
    [StringLength(20)]
    [RegularExpression(@"^\(\+57\)\s\d{10}$", ErrorMessage = "El formato debe ser (+57) 3144427602")]
    public string Phone { get; set; } = null!;

    [Required(ErrorMessage = "El correo electrónico es obligatorio")]
    [StringLength(100)]
    [EmailAddress(ErrorMessage = "El formato del correo electrónico no es válido")]
    public string Email { get; set; } = null!;

    [Required(ErrorMessage = "La fecha de nacimiento es obligatoria")]
    [DataType(DataType.Date)]
    [Column(TypeName = "date")]
    public DateTime DateOfBirth { get; set; }

    [NotMapped] // Este campo no se persiste en la base de datos
    public int Age
    {
        get
        {
            //Obtiene la fecha actual
            var today = DateTime.Today;

            //Calcula edad básica (año actual - año de nacimiento)
            var age = today.Year - DateOfBirth.Year;

            //Verifica si ya pasó el cumpleaños este año
            if (DateOfBirth.Date > today.AddYears(-age)) age--;

            //Retorna la edad calculada
            return age;
        }
    }

    [InverseProperty("Customer")]
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}